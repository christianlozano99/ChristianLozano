// Sean Szumlanski
// COP 3502, Fall 2018

// =============================
// Kindred Spirits: testcase12.c
// =============================
// Another test of the kindredSpirits() function.


#include <stdio.h>
#include "KindredSpirits.h"

int main(void)
{
	printf("%s\n", kindredSpirits(NULL, NULL) ? "Success!" : "fail whale :(");
	return 0;
}
